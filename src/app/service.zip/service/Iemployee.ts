export interface Iemployee
{
    "userId": number,
    "id": number,
    "title":string,
     "body": string
}

export interface Iemployee2
{
    "id": number,
    "name": string,
    "username": string,
    "email": string,
    "address": string[]
   
}